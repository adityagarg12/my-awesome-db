use anyhow::{Context, Result};
use clap::Parser;
use common::query::Query;
use db_config::DbContext;
use std::io::{BufRead, BufReader, Write};
use std::sync::{Arc, Mutex};

use crate::{
    catalog::Catalog,
    cli::CliOptions,
    disk_access::DiskAccessLayer,
    executor::{AnonBlockAllocator, build_operator},
    io_setup::{setup_disk_io, setup_monitor_io},
    optimizer::optimize,
    row::format_row_for_output,
};

mod block_codec;
mod catalog;
mod cli;
mod disk_access;
mod executor;
mod io_setup;
mod optimizer;
mod row;

fn db_main() -> Result<()> {
    let cli_options = CliOptions::parse();

    let ctx = DbContext::load_from_file(cli_options.get_config_path())?;
    let catalog = Catalog::from_db_context(&ctx)?;

    let (disk_in, disk_out) = setup_disk_io();
    let (monitor_in, mut monitor_out) = setup_monitor_io();

    let disk_access = Arc::new(Mutex::new(DiskAccessLayer::new(disk_in, disk_out)));
    let mut monitor_reader = BufReader::new(monitor_in);
    let mut line = String::new();

    // 1. Receive query
    monitor_reader.read_line(&mut line)?;
    let query: Query = serde_json::from_str(line.trim())
        .context("Failed to parse query JSON")?;

    // 2. Request memory limit
    monitor_out.write_all(b"get_memory_limit\n")?;
    monitor_out.flush()?;
    line.clear();
    monitor_reader.read_line(&mut line)?;
    let memory_limit_mb: u64 = line.trim().parse().context("Failed to parse memory limit")?;
    let memory_limit_bytes = memory_limit_mb * 1024 * 1024;

    // 3. Get block size and anonymous-region start from disk
    let block_size = {
        let mut disk = disk_access.lock().unwrap();
        disk.get_block_size()?
    };
    let anon_start = {
        let mut disk = disk_access.lock().unwrap();
        disk.get_anon_start_block()?
    };
    let anon_allocator = AnonBlockAllocator::new(anon_start);

    // Reserve memory for: buffer pool, prefetch windows, and untracked overhead.
    //
    // Untracked overhead includes:
    //   - Rust binary + stack:                   ~6 MB
    //   - merge_runs_to_disk batch buffer:         1 MB  (BATCH_BLOCKS × block_size)
    //   - DiskAccessLayer block cache:             1 MB  (BUFFER_POOL_BLOCKS × block_size)
    //   - Heap fragmentation (≈10 % of peak heap): scales with operator budget
    //
    // The dominant concern is that Sort(left)'s RunReaders and Sort(right)'s
    // chunk-filling can overlap in time.  With RunReader tracking (Fix #1 in
    // executor.rs) the global tracker enforces:
    //
    //   peak_process = operator_memory_limit + fixed_overhead
    //
    // where fixed_overhead ≈ 13 MB.  We therefore need:
    //
    //   operator_memory_limit ≤ memory_limit_bytes − fixed_overhead
    //
    // Using memory_limit_bytes / 4 as the safety reserve gives:
    //   64 MB → operator ≈ 47 MB, peak ≈ 60 MB  (4 MB headroom)
    //  128 MB → operator ≈ 95 MB, peak ≈ 108 MB (20 MB headroom)
    //  256 MB → operator ≈ 191 MB, peak ≈ 204 MB (52 MB headroom)
    const BUFFER_POOL_BLOCKS: u64 = 256;
    const PREFETCH_BLOCKS_PER_SCAN: u64 = 16;
    const MAX_CONCURRENT_SCANS: u64 = 2;
    let safety_fraction: u64 = memory_limit_bytes / 4;
    let buffer_reserved = (BUFFER_POOL_BLOCKS + PREFETCH_BLOCKS_PER_SCAN * MAX_CONCURRENT_SCANS)
        .saturating_mul(block_size)
        .saturating_add(safety_fraction);
    let operator_memory_limit = memory_limit_bytes.saturating_sub(buffer_reserved);

    // 4. Initialize global memory tracker with the usable operator budget.
    executor::init_memory_tracker(operator_memory_limit as usize);

    // 5. Optimize query tree, then build operator tree
    let optimized = optimize(query.root, &catalog);
    let mut root_op = build_operator(
        &optimized,
        &catalog,
        disk_access,
        block_size,
        operator_memory_limit,
        &anon_allocator,
    )?;

    // 6. Stream results to monitor
    monitor_out.write_all(b"validate\n")?;
    monitor_out.flush()?;
    while let Some(row) = root_op.next()? {
        let mut out = format_row_for_output(&row);
        out.push('\n');
        monitor_out.write_all(out.as_bytes())?;
    }
    monitor_out.write_all(b"!\n")?;
    monitor_out.flush()?;

    Ok(())
}

fn main() -> Result<()> {
    db_main().map_err(|e| {
        eprintln!("DATABASE ERROR: {:?}", e);
        e
    }).with_context(|| "From Database")
}
